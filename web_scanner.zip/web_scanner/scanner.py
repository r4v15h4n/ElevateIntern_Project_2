import requests
from bs4 import BeautifulSoup
import re

xss_payload = '"><script>alert("XSS")</script>'
sql_payload = "' OR '1'='1"

def find_forms(url):
    try:
        r = requests.get(url)
        soup = BeautifulSoup(r.text, "html.parser")
        return soup.find_all("form")
    except Exception as e:
        return []

from urllib.parse import quote

def is_vulnerable_xss(response):
    encoded_payload = quote(xss_payload)
    return xss_payload in response.text or encoded_payload in response.text

def is_vulnerable_sqli(response):
    errors = ["you have an error in your sql syntax", "warning: mysql", "unclosed quotation mark"]
    return any(error.lower() in response.text.lower() for error in errors)

def scan_url(url):
    results = []
    forms = find_forms(url)
    for form in forms:
        action = form.get("action")
        method = form.get("method", "get").lower()
        inputs = form.find_all("input")
        data = {}

        for i in inputs:
            name = i.get("name")
            if name:
                data[name] = xss_payload

        target_url = url if not action else requests.compat.urljoin(url, action)

        if method == "post":
            r = requests.post(target_url, data=data)
        else:
            r = requests.get(target_url, params=data)

        if is_vulnerable_xss(r):
            results.append(("XSS", target_url))
        if is_vulnerable_sqli(r):
            results.append(("SQL Injection", target_url))
    return results
