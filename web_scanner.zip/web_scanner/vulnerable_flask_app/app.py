from flask import Flask, request, render_template_string

app = Flask(__name__)

@app.route('/')
def index():
    return """
    <h2>Welcome to Vulnerable Flask App</h2>
    <ul>
        <li><a href='/xss'>XSS Test Page</a></li>
        <li><a href='/sqli'>SQLi Test Page</a></li>
    </ul>
    """

@app.route('/xss')
def xss():
    q = request.args.get("q", "")
    return render_template_string(f"""
        <h3>XSS Demo</h3>
        <form method='get'>
            <input name='q' placeholder='Enter something...' />
            <input type='submit' value='Submit' />
        </form>
        <p>You searched for: {q}</p>
    """)

@app.route('/sqli')
def sqli():
    username = request.args.get("username", "")
    if "'" in username or "--" in username or "1=1" in username:
        msg = "Possible SQL Injection detected!"
    else:
        msg = f"Welcome, {username}" if username else "Enter your username."
    return render_template_string(f"""
        <h3>SQLi Demo</h3>
        <form method='get'>
            <input name='username' placeholder='Enter username' />
            <input type='submit' value='Login' />
        </form>
        <p>{msg}</p>
    """)

if __name__ == "__main__":
    app.run(debug=True)
